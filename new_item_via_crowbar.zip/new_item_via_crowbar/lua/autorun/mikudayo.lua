player_manager.AddValidModel("Mikudayo","models/player/mikudayo.mdl")
player_manager.AddValidHands("Mikudayo","models/player/mikudayoarms.mdl",0,"0000000")