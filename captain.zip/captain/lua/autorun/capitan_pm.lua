player_manager.AddValidModel( "capitan_pm", "models/humans/group04/capitan_pm.mdl" )
player_manager.AddValidHands( "capitan_pm", "models/weapons/c_arms_combine.mdl" )
